﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webservice02.Models
{
    public class Contacto

    {
        public int ID{get;set;}
        public string nombre { get; set; }
    }
}